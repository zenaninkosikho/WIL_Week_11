<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointments</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <script src="../scripts/admin_script.js" defer></script>
    <link rel="stylesheet" href="/../styles/admin_styles.css">
    
</head>
<body>
    <div class="grid-container">
        <?php
            include '../partial/admin_header.php';
            include '../partial/admin_sidebar.php';
        ?>        

        <main class="main-container">
            <div class="top">
                <h1 class="main-title font-weight-bold">APPOINTMENTS</h1>
            </div>

                <div class="main-overview">
                <div class="overview-card">
                    <div class="overview-card__data">107</div>
                    <div class="overview-card__info">Appointments pending</div>
                </div>

                <div class="overview-card">
                    <div class="overview-card__data">460</div>
                    <div class="overview-card__info">Monthly appointments completed</div>
                </div>
             
                <div class="overview-card">
                    <div class="overview-card__data">12</div>
                    <div class="overview-card__info">Monthly appointments canceled</div>
                </div>
            </div>
<!--
            <div class="appointment-cards">
                <div class="card graph-l">
                    <canvas></canvas>
                </div>
                
                <div class="card graph-r" id="taskList">
                    <h1 class="main-title">TASKS</h1>
                    <div class="add-task">
                        <input type="text" autocomplete="off" placeholder="Add New Task" v-model="tasks.name" @keyup.enter="newItem" class="task-input">
                        <input type="submit" value="" class="submit-task" @click="newItem" title="Add Task">
                    </div>

                    <ul class="task-list">
                        <li class="task-list-item" v-for="task in tasks">
                            <label class="task-list-item-label">
                        <input type="checkbox">
                                <span>{{task.name}}</span>
                            </label>
                            <i class="fa fa-trash delete-btn"></i>
                        </li>
                    </ul>
                </div>
            </div>
            -->

            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>E-mail</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Service</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>01</td>
                            <td>Name Surname</td>
                            <td>example@gmail.com</td>
                            <td>03-24-22</td>
                            <td>10:00AM</td>
                            <td>manicure</td>
                        </tr>
                        <tr>
                            <td>02</td>
                            <td>John Doe</td>
                            <td>johndoe@gmail.com</td>
                            <td>03-25-22</td>
                            <td>11:00AM</td>
                            <td>pedicure</td>
                        </tr>
                        <tr>
                            <td>03</td>
                            <td>Alice Smith</td>
                            <td>alice.smith@example.com</td>
                            <td>03-26-22</td>
                            <td>09:30AM</td>
                            <td>haircut</td>
                        </tr>
                        <tr>
                            <td>04</td>
                            <td>Michael Johnson</td>
                            <td>michael.j@example.com</td>
                            <td>03-27-22</td>
                            <td>02:00PM</td>
                            <td>massage</td>
                        </tr>
                        <tr>
                            <td>05</td>
                            <td>Sarah Brown</td>
                            <td>sarah.brown@example.com</td>
                            <td>03-28-22</td>
                            <td>03:30PM</td>
                            <td>facial</td>
                        </tr>
                        <tr>
                            <td>06</td>
                            <td>David Wilson</td>
                            <td>david.w@example.com</td>
                            <td>03-29-22</td>
                            <td>10:30AM</td>
                            <td>manicure</td>
                        </tr>
                        <tr>
                            <td>07</td>
                            <td>Emily Taylor</td>
                            <td>emily.taylor@example.com</td>
                            <td>03-30-22</td>
                            <td>01:00PM</td>
                            <td>pedicure</td>
                        </tr>
                        <tr>
                            <td>08</td>
                            <td>James Anderson</td>
                            <td>james.a@example.com</td>
                            <td>03-31-22</td>
                            <td>11:30AM</td>
                            <td>haircut</td>
                        </tr>
                        <tr>
                            <td>09</td>
                            <td>Laura Martinez</td>
                            <td>laura.martinez@example.com</td>
                            <td>04-01-22</td>
                            <td>03:00PM</td>
                            <td>massage</td>
                        </tr>
                        <tr>
                            <td>10</td>
                            <td>Robert Lee</td>
                            <td>robert.lee@example.com</td>
                            <td>04-02-22</td>
                            <td>10:00AM</td>
                            <td>facial</td>
                        </tr>
                        <tr>
                            <td>11</td>
                            <td>Olivia Davis</td>
                            <td>olivia.davis@example.com</td>
                            <td>04-03-22</td>
                            <td>02:30PM</td>
                            <td>manicure</td>
                        </tr>
                        <tr>
                            <td>12</td>
                            <td>William Clark</td>
                            <td>william.c@example.com</td>
                            <td>04-04-22</td>
                            <td>12:00PM</td>
                            <td>pedicure</td>
                        </tr>
                        <tr>
                            <td>13</td>
                            <td>Natalie Rodriguez</td>
                            <td>natalie.r@example.com</td>
                            <td>04-05-22</td>
                            <td>09:00AM</td>
                            <td>haircut</td>
                        </tr>
                        <tr>
                            <td>14</td>
                            <td>Andrew Perez</td>
                            <td>andrew.p@example.com</td>
                            <td>04-06-22</td>
                            <td>01:30PM</td>
                            <td>massage</td>
                        </tr>
                        <tr>
                            <td>15</td>
                            <td>Sophia Hernandez</td>
                            <td>sophia.h@example.com</td>
                            <td>04-07-22</td>
                            <td>10:30AM</td>
                            <td>facial</td>
                        </tr>
                        <tr>
                            <td>16</td>
                            <td>Christopher Young</td>
                            <td>chris.y@example.com</td>
                            <td>04-08-22</td>
                            <td>02:00PM</td>
                            <td>manicure</td>
                        </tr>
                        <tr>
                            <td>17</td>
                            <td>Isabella King</td>
                            <td>isabella.k@example.com</td>
                            <td>04-09-22</td>
                            <td>11:00AM</td>
                            <td>pedicure</td>
                        </tr>
                        <tr>
                            <td>18</td>
                            <td>Benjamin Scott</td>
                            <td>benjamin.s@example.com</td>
                            <td>04-10-22</td>
                            <td>03:30PM</td>
                            <td>haircut</td>
                        </tr>
                        <tr>
                            <td>19</td>
                            <td>Ava Green</td>
                            <td>ava.g@example.com</td>
                            <td>04-11-22</td>
                            <td>09:30AM</td>
                            <td>massage</td>
                        </tr>
                        <tr>
                            <td>20</td>
                            <td>Henry Adams</td>
                            <td>henry.a@example.com</td>
                            <td>04-12-22</td>
                            <td>01:00PM</td>
                            <td>facial</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
</body>
</html>