<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CUSTOMERS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="../scripts/admin_script.js" defer></script>
    <link rel="stylesheet" href="/../styles/admin_styles.css">
    
</head>
<body>
    <div class="grid-container">
        <?php
            include '../partial/admin_header.php';
            include '../partial/admin_sidebar.php';
        ?> 

        <main class="main-container">
            <div class="top">
                <h1 class="main-title font-weight-bold">CUSTOMERS</h1>
            </div>
            
            <div class="customer-overview">
                <div class="overview-container">
                    <div class="overview-card">
                        <div class="overview-card__data">267</div>
                        <div class="overview-card__info">Customers</div>
                    </div>

                    <div class="overview-card">
                        <div class="overview-card__data">229</div>
                        <div class="overview-card__info">Subscribers</div>
                    </div>
                
                    <div class="overview-card">
                        <div class="overview-card__data">62</div>
                        <div class="overview-card__info">Loyalty Members</div>
                    </div>
                </div>
                <div class="customer-line-graph">
                    <canvas id="customer-number"></canvas>
                </div>
            </div>


            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Number</th>
                            <th>State</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>1</td>
                            <td>John Doe</td>
                            <td>john@example.com</td>
                            <td>1234567890</td>
                            <td>Subscribed</td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td>Jane Smith</td>
                            <td>jane@example.com</td>
                            <td>9876543210</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td>Michael Johnson</td>
                            <td>michael@example.com</td>
                            <td>5551234567</td>
                            <td>Subscribed</td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td>Alice Brown</td>
                            <td>alice@example.com</td>
                            <td>3216544876</td>
                            <td>Subscribed</td>
                        </tr>
                        <tr>
                            <td>5</td>
                            <td>Robert Smith</td>
                            <td>robert@example.com</td>
                            <td>4567891230</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>6</td>
                            <td>Sarah Johnson</td>
                            <td>sarah@example.com</td>
                            <td>7890123456</td>
                            <td>Subscribed</td>
                        </tr>
                        <tr>
                            <td>7</td>
                            <td>David Lee</td>
                            <td>david@example.com</td>
                            <td>2345678901</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>8</td>
                            <td>Emily Davis</td>
                            <td>emily@example.com</td>
                            <td>8765432109</td>
                            <td>Subscribed</td>
                        </tr>
                        <tr>
                            <td>9</td>
                            <td>James Wilson</td>
                            <td>james@example.com</td>
                            <td>6543210987</td>
                            <td>Subscribed</td>
                        </tr>
                        <tr>
                            <td>10</td>
                            <td>Laura Martinez</td>
                            <td>laura@example.com</td>
                            <td>1098765432</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>11</td>
                            <td>Christopher Brown</td>
                            <td>christopher@example.com</td>
                            <td>3210987654</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>12</td>
                            <td>Emma Taylor</td>
                            <td>emma@example.com</td>
                            <td>5432109876</td>
                            <td>Subscribed</td>
                        </tr>
                        <tr>
                            <td>13</td>
                            <td>Matthew Anderson</td>
                            <td>matthew@example.com</td>
                            <td>2109876543</td>
                            <td>Subscribed</td>
                        </tr>
                        <tr>
                            <td>14</td>
                            <td>Olivia Thomas</td>
                            <td>olivia@example.com</td>
                            <td>4321098765</td>
                            <td>-</td>
                        </tr>
                        <tr>
                            <td>15</td>
                            <td>William Garcia</td>
                            <td>william@example.com</td>
                            <td>8765432109</td>
                            <td>Subscribed</td>
                        </tr>
                    </tbody>
                </table> 
            </div>
        </main>
    </div>
</body>
</html>

        