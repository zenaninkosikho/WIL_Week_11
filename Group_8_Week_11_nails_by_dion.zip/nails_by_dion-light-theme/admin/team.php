<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Team</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" />
    <script src="../scripts/admin_script.js" defer></script>
    <link rel="stylesheet" href="/../styles/admin_styles.css">

</head>

<body>
    <div class="grid-container">
        <?php
            include '../partial/admin_header.php';
            include '../partial/admin_sidebar.php';
        ?>

        <main class="main-container">
            <div class="top">
                <h1 class="main-title font-weight-bold">TEAM</h1>
            </div>

            <div class="deck">

                <div class="add-card">
                    <form id="add-member-form">
                        <h3>Add New Member</h3>
                        <input type="text" id="member-name" placeholder="Name" required>
                        <input type="email" id="member-email" placeholder="Email" required>
                        <input type="text" id="member-role" placeholder="Role" required>
                        <button type="submit">Add</button>
                    </form>
                </div>

                <div class="card-container">
                    <div class="team-card">
                        <img id="team-pic" src="../_images/profile-pic blank.jpeg" alt="team-profile photo">
                        <p id="team-name">John Doe</p>
                        <p id="team-email">john@example.com</p>
                        <div class="card-bottom">
                            <p class="team-role">stylist</p>
                            <button id="team-view">View</button>
                        </div>
                    </div>
                </div>

                <div class="card-container">
                    <div class="team-card">
                        <img id="team-pic" src="../_images/profile-pic blank.jpeg" alt="team-profile photo">
                        <p id="team-name">Name</p>
                        <p id="team-email">Email</p>
                        <div class="card-bottom">
                            <p class="team-role">Role</p>
                            <button id="team-view">View</button>
                        </div>
                    </div>
                </div>

                <div class="card-container">
                    <div class="team-card">
                        <img id="team-pic" src="../_images/profile-pic blank.jpeg" alt="team-profile photo">
                        <p id="team-name">Name</p>
                        <p id="team-email">Email</p>
                        <div class="card-bottom">
                            <p class="team-role">Role</p>
                            <button id="team-view">View</button>
                        </div>
                    </div>
                </div>

                <div class="card-container">
                    <div class="team-card">
                        <img id="team-pic" src="../_images/profile-pic blank.jpeg" alt="team-profile photo">
                        <p id="team-name">Name</p>
                        <p id="team-email">Email</p>
                        <div class="card-bottom">
                            <p class="team-role">Role</p>
                            <button id="team-view">View</button>
                        </div>
                    </div>
                </div>

                <div class="card-container">
                    <div class="team-card">
                        <img id="team-pic" src="../_images/profile-pic blank.jpeg" alt="team-profile photo">
                        <p id="team-name">Name</p>
                        <p id="team-email">Email</p>
                        <div class="card-bottom">
                            <p class="team-role">Role</p>
                            <button id="team-view">View</button>
                        </div>
                    </div>
                </div>
            </div>
        </main>
       
</body>

</html>