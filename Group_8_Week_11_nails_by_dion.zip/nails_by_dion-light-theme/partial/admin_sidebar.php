
<aside id="sidebar">
  <div class="sidebar-title">

    <div class="sidebar-brand">
      <!--Logo--> Nails By Dion
    </div>

    <div class="close-icon" onclick="closeSidebar()">
      <i class="fa fa-x"></i>
    </div>

  </div>

  <ul class="sidebar-list">
    <a href="dashboard.php">
      <li class="sidebar-list-item">
        Dashboard
      </li>
    </a>
<!--
    <a href="admin_services.php">
      <li class="sidebar-list-item">
          Services 
      </li>
    </a>
-->
    <a href="appointment.php">
      <li class="sidebar-list-item">
          Appointments
      </li> 
    </a>

    <a href="customer.php">
      <li class="sidebar-list-item">
          Customers
      </li>
    </a>

    <a href="team.php">
      <li class="sidebar-list-item">
          Team
      </li>
    </a>

    <a href="sale.php">
      <li class="sidebar-list-item">
          Sales 
      </li>
    </a>
<!--
    <a href="report.php">
      <li class="sidebar-list-item">
          Report
      </li>
    </a>
-->
  </ul>
</aside>
