<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <link rel="stylesheet" href="/../styles/client_styles.css">
</head>
<body>
    <?php $page = 'appointment'; include '../partial/header.php';?>

<div id="popupBack" class="popupBackground"> <!--popup background-->

        <div class="popupBlock"  ><!--popup block-->
        
        <div id="filterPane">

            <div id="paneContent">
                <h3 class='heading'>Service Details</h3>
                <br>
                <table id='timer'>
                    <tr>
                        <td id='subhour' onclick="newformatter.subhour()"> - </td>
                        <td id='addhour' onclick="newformatter.addhour()">+</td>
                        <td id='hour'>7</td>
                        <td>:</td>
                        <td id='minute'>10</td>
                        <td id='submin' onclick="newformatter.submin()">-</td>
                        <td id='addmin' onclick="newformatter.addmin()">+</td>
                    </tr>
                </table>
                    <table id='mainTable'>
                        <tr>
                            <td>
                                <img src="../_images\2.jpg" width="90" height="90">
                            </td>
                            
                            <td>
                            </td>

                            <td>
                                    <table>
                                        <tr>
                                            
                                            <td>
                                                <p>Name of service</p>
                                            </td>
                                            <td>
                                                <p>price of service</p>
                                            </td>

                                            <td>
                                                <p>price of service</p>
                                            </td>
                                        </tr>
                                        
                                        <tr>
                                            
                                            <td>
                                                <p>Name of service</p>
                                            </td>
                                            <td>
                                                <p>price of service</p>
                                            </td>

                                            <td>
                                                <p>price of service</p>
                                            </td>
                                        </tr>
                                    </table>
                            </td>

                        </tr>
                        <tr>
                            
                        </tr>
                    </table>
                    
                        
                            <div id="filterDetails">
                                
                                
                            </div>
                        

                
                <table id=description>
                    
                    <tr>
                        <td>
                            <p>
                                description of service- it could be a long or a 
                                very short paragraph. it is mainly meant for 
                                someone who is newly interacting with the site
                            </p>
                        </td>
                    </tr>
                </table>
                
                <br>
                <h4 class='subheading'>Stylists</h4>
                <table id='stylists'>
                    <tr>
                        <td><input type="checkbox" ><label for="stylistname">stylists name</label><br></td>
                        <td><input type="checkbox"><label for="stylistname">stylists name</label><br>
                        </td>
                        <td><input type="checkbox"><label for="stylistname">stylists name</label><br>
                        </td>
                        <td><input type="checkbox"><label for="stylistname">stylists name</label>
                        </td>
                    </tr>
                </table>
                <br>
                
            </div>
        </div>

    <button id="closePopup" onclick='newformatter.removePop()'>Close</button>        
</div>

</div>

    <style>

        .popupBackground 
        {
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
            display: none;
        }

        .popupBlock 
        {
            background-color: white;
            margin-top: 3% ;
            margin-left:13%;
            padding: 20px;
            border: 1px solid #888888;
            width: 70%;
            height: 80%;
            font-weight: bolder;
            border-radius: 20px;
        }

        #sDetails
        {
            margin-left:15%;
        }

        #filterPane
        {
            top:250px;
            left:805px;
            width:20cm;
            height: fit-content;
            margin-left:29px;
            margin-top: 35px;
        }

        #description
        {
            width: 120%;
            margin-top: 0%;
            font-weight: 200;
        }

        #timer
        {
            margin-left: 27%;
            font-size: 20pt;
        }

        #stylists
        {
            width: 120%;
            font-weight: 200;
        }

        

        

        

        #closePopup
        {
            background-color: burlywood;
            border-style:none;
            width: 2cm;
            height: 1cm;
            margin-left: 500px;
            margin-top:15px;
            color: white;
            border-radius: 15px;
                
        }

        #closePopup:hover
        {
            background-color: rgb(180, 145, 101);
        }

        .show 
        {
            display: block;   
        }
        
        h
        {
          
            font-size: 16pt;
            margin-left: 4%;
        }

        img
        {
            height: 100px;
            width: 100px;
            border-radius: 15%;
        }

        
        #shortlisted
        {
            height: 100px;
            width: 100px;
            position: fixed;
            margin-left: 92%;
            margin-top: 25%;
            opacity: 0.2;

            
        }
        #shortlisted:hover
        {
            height: 105px;
            width: 105px;
            position: fixed;

            opacity: 1;  
            transition:all 150ms ease-in; 
        }

      #mainTable
      {
        width: 120%;
        margin-top: 0%;
        font-weight: 200;
      }

      .subheading
      {
        margin-left: 7%;
        font-weight: 700;
      }
      .heading
      {
        margin-left: 5%;
      }

      
            
    </style>

    <style>



    table {
    width: 80%;
    margin-bottom: 20px;
    margin-left: 7%;
    border-collapse: collapse;
    font-family: Arial, Helvetica, sans-serif;
    border: none; 
    border-radius: 10px; 
    overflow: hidden; 
}

th, td {
    padding: 8px;
    text-align: center;
}

th {
    background-color: rgb(216, 206, 206);
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}

.header-row {
    display: flex;
    align-items: center;
    margin-bottom: 10px; 
}

.title {
    flex: 1; 
    margin-right: 10px; 
}

.search-bar {
    width: 200px; 
    margin-right: 10px; 
    border-radius: 20px; 
    padding: 5px; 
    background-color: #f2f2f2;
}

td {
    cursor: pointer; 
}

.filter-dropdown {
    width: 20px; 
    margin-right: 10px; 
    border-radius: 20px; 
    padding: 5px;
    background-color: #f2f2f2;
}
    

    </style>

    <script>

        class formatter
        {
            showStatus()
            {
                var space=document.createElement('br');
                //space.textContent="Appointments ";//must point an array elemnt
                document.body.append(space); 

                var subheading=document.createElement('h3');
                subheading.textContent="Appointments' status ";//must point an array elemnt
                subheading.setAttribute('class','subheading');
                document.body.append(subheading); 

                var table=document.createElement('table');
                    document.body.appendChild(table);
                    table.setAttribute('class','table');
                    table.setAttribute('id','table');

                    row=document.createElement('tr');
                    table.append(row);

                    cell=document.createElement('td');
                    cell.textContent="Appointment Deposit";//must point an array elemnt
                    row.append(cell); 

                    
                    cell=document.createElement('td');
                    cell.textContent=" ";//must point an array elemnt
                    row.append(cell); 
                    

                    cell=document.createElement('td');
                    cell.textContent="Appointment Status ";//must point an array elemnt
                    row.append(cell);

                    var row;
                    var rows=0;
                    var totalrows= localStorage.length;
                    var cells=0;
                    var cell;
                    var sets=0;
                    var numbering=0;
                    var deposit=Math.floor(Math.random()*2000);
                        
                        //these are determined by number of keys
                        while(rows<1)
                        {
                            row=document.createElement('tr');
                            table.append(row);
                            numbering++;

                            //cells here have to get data from the arrays
                            cell=document.createElement('td');
                            cell.textContent='R '+deposit;//must point an array elemnt
                            row.append(cell); 
                            numbering++;
                            
                            

                            cell=document.createElement('td');
                            cell.textContent="";
                            row.append(cell);
                            numbering++;

                            cell=document.createElement('td');
                            cell.textContent="Awaiting Confirmation ";
                            row.append(cell);
                            
                            rows++;
                        }

            }

            showAppointments()
            {


                var space=document.createElement('br');
                //space.textContent="Appointments ";//must point an array elemnt
                document.body.append(space); 
                var space=document.createElement('br');
                //space.textContent="Appointments ";//must point an array elemnt
                document.body.append(space); 
                
                var space=document.createElement('br');
                //space.textContent="Appointments ";//must point an array elemnt
                document.body.append(space); 

                var subheading=document.createElement('h3');
                subheading.textContent="Appointments ";//must point an array elemnt
                subheading.setAttribute('class','subheading');
                document.body.append(subheading); 

              


                var table2=document.createElement('table');
                    document.body.appendChild(table2);

                    table2.setAttribute('class','table2');
                    table2.setAttribute('id','table2');
                    row2=document.createElement('tr');
                    table2.append(row2);
                    
                    subheading=document.createElement('tr');
                    table2.append(subheading);
                    cell2=document.createElement('td');
                    cell2.textContent="Service ";//must point an array elemnt
                    row2.append(cell2); 
                    

                    
                    
                    cell2=document.createElement('td');
                    cell2.textContent=" ";//must point an array elemnt
                    row2.append(cell2);
                    
;
                    

                    cell2=document.createElement('td');
                    cell2.textContent="Cancel All";//must point an array elemnt
                    cell2.setAttribute('onclick','newformatter.removeAllRows()');
                    row2.append(cell2);
                    
                    
                    var row2;
                    var rows2=0;
                    var totalrows= localStorage.length;
                    var cells=0;
                    var cell2;
                    var sets=0;
                    var numbering2=0;
                    var rowsCreated=Math.floor(Math.random()*8);
                    
                    
                    var rowNumber=0;
                    
                       //each row must have id, cancel must cancel using this id 
                        //these are determined by number of keys
                        while(rows2<rowsCreated)
                        {
                            var idName='row'+rowNumber;
                            row2=document.createElement('tr');
                            row2.setAttribute('id',idName);
                            table2.append(row2);
                            numbering2++;

                            //cells here have to get data from the arrays
                            cell2=document.createElement('td');
                            cell2.textContent=Math.floor(Math.random()*23)+":"+Math.floor(Math.random()*59);//must point an array elemnt
                            cell2.setAttribute('className', 'data');
                            cell2.setAttribute('onclick','newformatter.showPop()');
                            row2.append(cell2); 
                            numbering2++;



                            //give handle             
                            cell2=document.createElement('td');
                            cell2.textContent="This will be a brief description of the notification...";
                            cell2.setAttribute('id','appointmentDetails');
                            cell2.setAttribute('onclick','newformatter.showPop()');
                            row2.append(cell2);
                            numbering2++;



                            cell2=document.createElement('td');
                            cell2.textContent="Cancel";
                            cell2.setAttribute('onclick', 'newformatter.removeRows('+idName+')');
                            row2.append(cell2);
                            
                            rows2++;
                            rowNumber++;
                        }

                    //sets++;
            }

            removeAllRows()
            {
               
                    table2.remove();
               
               return 0;
            }

            removeRows(rowToDelete)
            {
                //var row=document.getElementById(''+rowToDelete+'');
                rowToDelete.remove();
                
            }



            showPop(info)
            {
                //this popup must alter elements and content in the popup
                popupBack.classList.add("show");
                var textdata=document.getElementById('textdata');
                
                if(info==1)
                {
                    textdata.textContent="First";
                }
                
                if(info==2)
                {
                    textdata.textContent="Second";
                }

                if(info==1000)
                {
                    textdata.textContent="This is the shortlist";
                }
                
            }

            removePop()
            {
                popupBack.classList.remove("show");
            }

            removeByBackground()
            {
                if (event.target == popupBack) 
                {
                    popupBack.classList.remove("show");
                }
            }

            start=7;
            addhour()
            {
                var hAdder=document.getElementById('hour');
                this.start++;

                hAdder.textContent=this.start;
            }

            subhour()
            {
                var hAdder2=document.getElementById('hour');
                this.start--;

                hAdder2.textContent=this.start;
            }

            minStart=10;
            addmin()
            {
                var hAdder=document.getElementById('minute');
                this.minStart++;

                hAdder.textContent=this.minStart;
            }

            submin()
            {
                var hAdder2=document.getElementById('minute');
                this.minStart--;

                hAdder2.textContent=this.minStart;
            }

        }
        
        var newformatter= new formatter(); 
        newformatter.showStatus();
        newformatter.showAppointments();
        //newformatter.runPopup();
        //newformatter.addEventListener("click", function () { newformatter.removePop(); });

    
    </script>
    <?php include '../partial/footer.php';?>    

    
</body>
</html>