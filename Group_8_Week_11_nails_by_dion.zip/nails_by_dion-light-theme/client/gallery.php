<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gallery</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <link rel="stylesheet" href="/../styles/client_styles.css">
</head>
<body>
    <?php $page = 'gallery'; include '../partial/header.php';?>
    <h>Gallery</h>
    <img src="_images\logo.png" id="shortlisted" onclick="myController.showPop(1000)">
    <table id='galleryTable'>
        <tr>
            <td>
                <table>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\4.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\5.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\6.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\7.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\8.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\9.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                </table>
            </td>
            
            <td><table>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\9.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\8.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\7.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\6.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\5.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\4.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    </table>
            </td>

            <td>
                <table>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\4.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\5.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\6.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\7.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\8.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\9.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                </table>
            </td>
            
            <td><table>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\9.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\8.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\7.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\6.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\5.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    <tr class='Grows'><td class='Gimage'><img src="../_images\4.png" width="150" height="150" onclick="myController.showPop()"></td>
                    <td class='imageDetail'>Description</td></tr>
                    </table>
            </td>
            
        </tr>
    </table>

    <div id="popupBackG" class="popupBackground"><!--popup background-->

<div class="popupBlock"  ><!--popup block-->
    
    <div id="filterPaneG">

        <div id="paneContentG">
            <h3>Service Details</h3>
            <br>
            <table >
                <tr>
                    <td id="filterTableG"><img src="../_images\2.jpg" width="90" height="90"></td>
                    <td id="filterTableG">
                        <div id="filterDetailsG">
                            <p>Name of service</p>
                            <p>price of service</p>
                        </div>
                    </td>
                </tr>
            </table>

            <p id='textdataG'>The price is x</p>

            <p>description of service- it could be a long or a 
                very short paragraph. it is mainly meant for 
                someone who is newly interacting with the site
            </p>
            
            <br>
            <h4>Stylists</h4>
            <table>
                <tr>
                    <td><input type="checkbox" ><label for="stylistname">stylists name</label><br></td>
                    <td><input type="checkbox"><label for="stylistname">stylists name</label><br>
                    </td>
                    <td><input type="checkbox"><label for="stylistname">stylists name</label><br>
                    </td>
                    <td><input type="checkbox"><label for="stylistname">stylists name</label>
                    </td>
                </tr>
            </table>
            <br>
            
        </div>
    </div>

    <button id="closePopupG">Close</button>        
</div>

</div>



<button></button>

<script>

class controller
{
    //How can JavaScript move data into another page

    showPop(info)
    {
        //this popup must alter elements and content in the popup
        popupBackG.classList.add("show");
        var textdataG=document.getElementById('textdataG');
        
        if(info==1)
        {
            textdataG.textContent="First";
        }
        
        if(info==2)
        {
            textdataG.textContent="Second";
        }

        if(info==1000)
        {
            textdataG.textContent="This is the shortlist";
        }
        
    }
    
    removePop()
    {
        popupBackG.classList.remove("show");
    }

    removeByBackground()
    {
        if (event.target == popupBackG) 
        {
            popupBackG.classList.remove("show");
        }
    }
}

myController=new controller();

shortlisted.addEventListener("click", function () { myController.showPop(); });
closePopupG.addEventListener("click", function () { myController.removePop();});
window.addEventListener("click", function (event) {myController.removeByBackground();});

</script>

<style>

.popupBackground 
{
    position: fixed;
    z-index: 1;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0, 0, 0, 0.4);
    display: none;
}

.popupBlock 
{
    background-color: white;
    margin-top: 3% ;
    margin-left:13%;
    padding: 20px;
    border: 1px solid #888888;
    width: 70%;
    height: 80%;
    font-weight: bolder;
    border-radius: 20px;
}

#sDetails
{
    margin-left:15%;
}

#filterPaneG
{
    top:250px;
    left:805px;
    width:20cm;
    height: fit-content;
    margin-left:170px;
    margin-top: 35px;
}

#filterDetailsG
{
    position:relative;
    margin-left: 30px;
   
}

#filterTableG
{
    width: 4cm;
}

#galleryTable
{
    margin-left: 130px;
    width:35cm;
}

.imageDetail
{
    margin-left: 13cm;
    background-color: #F3E6D9;
    text-align: left;
}

.Gimage
{
    width: 4cm;
}

.Grows
{
    height: 3.5cm;
}

#closePopupG
{
    background-color: burlywood;
    border-style:none;
    width: 2cm;
    height: 1cm;
    margin-left: 500px;
    margin-top:15px;
    color: white;
    border-radius: 15px;
        
}

#closePopupG:hover
{
    background-color: rgb(180, 145, 101);
}

.show 
{
    display: block;   
}

h
{
  
    font-size: 16pt;
    margin-left: 4%;
}

img
{
    height: 100px;
    width: 100px;
    border-radius: 15%;
}

img:hover
{
    height: 90px;
    width: 90px;
    border-radius: 15%;

    border-width: 5pt;
    border-color: white;
    border-style: solid;
  
    transition: all 200ms ease-in-out;
}

#shortlisted
{
    height: 100px;
    width: 100px;
    position: fixed;
    margin-left: 92%;
    margin-top: 25%;
    opacity: 0.2;

    
}
#shortlisted:hover
{
    height: 105px;
    width: 105px;
    position: fixed;

    opacity: 1;  
    transition:all 150ms ease-in; 
}

#serviceList
{
    margin-left:7%;
}

td
{
    width: 9cm;
}
    
</style>

    <style>
        table 
        {
            width: 100%;
            border-collapse: collapse;
            font-family: Arial, Helvetica, sans-serif;
            border: none; 
            border-radius: 10px; 
            overflow: hidden; 
        }

        th, td 
        {
            padding: 8px;
            text-align: center;
        }

        th 
        {
            background-color: rgb(216, 206, 206);
        }

        tr:nth-child(even) {
            background-color: #F3E6D9;
        }

        .header-row {
            display: flex;
            align-items: center;
            margin-bottom: 10px; 
        }

        .title {
            flex: 1; 
            margin-right: 10px; 
        }

        .search-bar {
            width: 200px; 
            margin-right: 10px; 
            border-radius: 20px; 
            padding: 5px; 
            background-color: #f2f2f2;
        }

        td {
            cursor: pointer; 
        }

        .filter-dropdown {
            width: 20px; 
            margin-right: 10px; 
            border-radius: 20px; 
            padding: 5px; 
            background-color: #f2f2f2;
        }

    </style>

    <?php include '../partial/footer.php';?>
</body>
</html>