<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <link rel="stylesheet" href="/../styles/client_styles.css">
    <script src="../scripts/client_script.js" defer></script>
</head>
<body>
    <?php /*$page = 'home'; include '../partial/header.php';*/?>
    <?php $page = 'home'; include '../partial/header.php';?>
    <br>
    <h> Services</h>
    <br>

    <br>
	<img src="_images\logo.png" id="shortlisted" onclick="myController.showPop(1000)">

    <div id="serviceList">
    <h3>Eyebrows</h3>
    <table>
        <tr>
            <td><img src="../_images\1.jpg" width="150" height="150" onclick="myController.showPop(1)">
            </td>
            <td><img src="../_images\2.jpg" width="150" height="150" onclick="myController.showPop(2)">
            </td>
            <td><img src="../_images\3.jpg" width="150" height="150" onclick="myController.showPop()">
            <td><img src="../_images\3.jpg" width="150" height="150" onclick="myController.showPop()">
            <td><img src="../_images\3.jpg" width="150" height="150" onclick="myController.showPop()">
            
            </td>
        </tr>
        <tr>
            <td><p id="sDetails">service x<br> R100.00</p></td>
            <td><p id="sDetails">service x<br> R100.00</p></td>
            <td><p id="sDetails">service x<br> R100.00</p></td>
            <td><p id="sDetails">service x<br> R100.00</p></td>
            <td><p id="sDetails">service x<br> R100.00</p></td>
        </tr>
    </table>

    
    <br>

    <h3>Nails</h3>
    <table>
        <tr>
            <td><img src="../_images\4.png" width="150" height="150" onclick="myController.showPop()">
            </td>
            <td><img src="../_images\5.png" width="150" height="150" onclick="myController.showPop()">
            </td>
            <td><img src="../_images\6.png" width="150" height="150" onclick="myController.showPop()">
            </td>
            <td><img src="../_images\6.png" width="150" height="150" onclick="myController.showPop()">
            </td>
            <td><img src="../_images\6.png" width="150" height="150" onclick="myController.showPop()">
            </td>
        </tr>
        <tr>
            <td><p id="sDetails">service x<br> R100.00</p></td>
            <td><p id="sDetails">service x<br> R100.00</p></td>
            <td><p id="sDetails">service x<br> R100.00</p></td>
            <td><p id="sDetails">service x<br> R100.00</p></td>
            <td><p id="sDetails">service x<br> R100.00</p></td>
        </tr>
    </table>
    
    <h3>Hair</h3>
    <table>
        <tr>
            <td><img src="../_images\7.png" width="150" height="150" onclick="myController.showPop()">
            </td>
            <td><img src="../_images\8.png" width="150" height="150" onclick="myController.showPop()">
            </td>
            <td><img src="../_images\9.png" width="150" height="150" onclick="myController.showPop()">
            </td>
            <td><img src="../_images\9.png" width="150" height="150" onclick="myController.showPop()">
            </td>
            <td><img src="../_images\9.png" width="150" height="150" onclick="myController.showPop()">
            </td>
        </tr>
        <tr>
            <td><p id="sDetails">service x<br> R100.00</p></td>
            <td><p id="sDetails">service x<br> R100.00</p></td>
            <td><p id="sDetails">service x<br> R100.00</p></td>
            <td><p id="sDetails">service x<br> R100.00</p></td>
            <td><p id="sDetails">service x<br> R100.00</p></td>
        </tr>
    </table>

    <h3>Waxing</h3>
    <table>
        <tr>
            <td><img src="../_images\10.jpg" width="150" height="150" onclick="myController.showPop()">
            </td>
            <td><img src="../_images\11.jpg" width="150" height="150" onclick="myController.showPop()">
            </td>
            <td><img src="../_images\12.jpg" width="150" height="150" onclick="myController.showPop()">
            </td>
            <td><img src="../_images\12.jpg" width="150" height="150" onclick="myController.showPop()">
            </td>
            <td><img src="../_images\12.jpg" width="150" height="150" onclick="myController.showPop()">
            </td>
        </tr>
        <tr>
            <td><p id="sDetails">service x<br> R100.00</p></td>
            <td><p id="sDetails">service x<br> R100.00</p></td>
            <td><p id="sDetails">service x<br> R100.00</p></td>
            <td><p id="sDetails">service x<br> R100.00</p></td>
            <td><p id="sDetails">service x<br> R100.00</p></td>
        </tr>
    </table>
    <br>
    <br>
    <br>
</div>
    
    <div id="popupBack" class="popupBackground"><!--popup background-->

		<div class="popupBlock"  ><!--popup block-->
            
            <div id="filterPane">

                <div id="paneContent">
                    <h3>Service Details</h3>
                    <br>
                    <table >
                        <tr>
                            <td id="filterTable"><img src="../_images\2.jpg" width="90" height="90"></td>
                            <td id="filterTable">
                                <div id="filterDetails">
                                    <p>Name of service</p>
                                    <p>price of service</p>
                                </div>
                            </td>
                        </tr>
                    </table>

                    <p id='textdata'>The price is x</p>

                    <p>description of service- it could be a long or a 
                        very short paragraph. it is mainly meant for 
                        someone who is newly interacting with the site
                    </p>
                    
                    <br>
                    <h4>Stylists</h4>
                    <table>
                        <tr>
                            <td><input type="checkbox" ><label for="stylistname">stylists name</label><br></td>
                            <td><input type="checkbox"><label for="stylistname">stylists name</label><br>
                            </td>
                            <td><input type="checkbox"><label for="stylistname">stylists name</label><br>
                            </td>
                            <td><input type="checkbox"><label for="stylistname">stylists name</label>
                            </td>
                        </tr>
                    </table>
                    <br>
                    
                </div>
            </div>

        <table id='lastButtons'>
            <tr>
                <td>
                <button id="Book" onclick='newformatter.removePop()'>Book</button>
                </td>
                    
                <td>
                
                    <button id="closePopup" onclick='newformatter.removePop()'>Close</button>
                </td>
            </tr>
        </table>

        </div>

	</div>
    


    <button></button>

    <script>

        class controller
        {
            //How can JavaScript move data into another page

            showPop(info)
            {
                //this popup must alter elements and content in the popup
                popupBack.classList.add("show");
                var textdata=document.getElementById('textdata');
                
                if(info==1)
                {
                    textdata.textContent="First";
                }
                
                if(info==2)
                {
                    textdata.textContent="Second";
                }

                if(info==1000)
                {
                    textdata.textContent="This is the shortlist";
                }
                
            }
            
            removePop()
            {
                popupBack.classList.remove("show");
            }

            removeByBackground()
            {
                if (event.target == popupBack) 
                {
                    popupBack.classList.remove("show");
                }
            }
        }

        myController=new controller();
        
        shortlisted.addEventListener("click", function () { myController.showPop(); });
        closePopup.addEventListener("click", function () { myController.removePop();});
        window.addEventListener("click", function (event) {myController.removeByBackground();});

    </script>
		
    <style>

        .popupBackground 
        {
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
            display: none;
        }

        .popupBlock 
        {
            background-color: white;
            margin-top: 3% ;
            margin-left:13%;
            padding: 20px;
            border: 1px solid #888888;
            width: 70%;
            height: 80%;
            font-weight: bolder;
            border-radius: 20px;
        }

        #sDetails
        {
            margin-left:15%;
        }

        #filterPane
        {
            top:250px;
            left:805px;
            width:20cm;
            height: fit-content;
            margin-left:170px;
            margin-top: 5px;
        }

        #filterDetails
        {
            position:relative;
            margin-left: 30px;
           
        }

        #filterTable
        {
            width: 4cm;
        }

        #Book
        {
            background-color: burlywood;
            border-style:none;
            width: 2cm;
            height: 1cm;
            margin-left: 300px;
            margin-top:15px;
            color: white;
            border-radius: 15px;
                
        }

        #closePopup
        {
            background-color: burlywood;
            border-style:none;
            width: 2cm;
            height: 1cm;
            margin-left: 200px;
            margin-top:35px;
            color: white;
            border-radius: 15px;
                
        }
        
        #Book:hover
        {
            background-color: rgb(180, 145, 101);
        }

        #closePopup:hover
        {
            background-color: rgb(180, 145, 101);
        }

        #lastButtons
        {
            
            width: 80%;
        }

        .show 
        {
            display: block;   
        }
        
        h
        {
          
            font-size: 16pt;
            margin-left: 4%;
        }

        img
        {
            height: 150px;
            width: 150px;
            border-radius: 15%;
        }

        img:hover
        {
            height: 130px;
            width: 130px;
            border-radius: 15%;

            border-width: 5pt;
            border-color: white;
            border-style: solid;
          
            transition: all 200ms ease-in-out;
        }
        
        #shortlisted
        {
            height: 100px;
            width: 100px;
            position: fixed;
            margin-left: 92%;
            margin-top: 25%;
            opacity: 0.2;

            
        }
        #shortlisted:hover
        {
            height: 105px;
            width: 105px;
            position: fixed;

            opacity: 1;  
            transition:all 150ms ease-in; 
        }

        #serviceList
        {
            margin-left:7%;
        }

        td
        {
            width: 9cm;
        }
            
    </style>
    <?php include '../partial/footer.php';?>
</body>
</html>