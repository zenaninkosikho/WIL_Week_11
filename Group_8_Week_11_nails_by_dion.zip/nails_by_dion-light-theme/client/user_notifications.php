<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <link rel="stylesheet" href="/../styles/client_styles.css">
</head>
<body>
    <?php $page = 'notification'; include '../partial/header.php';?>

<div id="popupBack" class="popupBackground"> <!--popup background-->

        <div class="popupBlock"  ><!--popup block-->
        
        <div id="filterPane">

            <div id="paneContent">
                <h3>Notification</h3>
                <br>

                            <div id="filterDetails">
                                <p>Name of service</p>
                                <p>price of service</p>
                            </div>
                        

                <p id='textdata'>The price is x</p>

                <p>description of service- it could be a long or a 
                    very short paragraph. it is mainly meant for 
                    someone who is newly interacting with the site
                </p>
                
                <br>
                <h4>Stylists</h4>
                
                <br>
                
            </div>
        </div>

    <button id="closePopup" onclick='newformatter.removePop()'>Close</button>        
</div>

</div>

    <style>

        .popupBackground 
        {
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
            display: none;
        }

        .popupBlock 
        {
            background-color: white;
            margin-top: 3% ;
            margin-left:13%;
            padding: 20px;
            border: 1px solid #888888;
            width: 70%;
            height: 80%;
            font-weight: bolder;
            border-radius: 20px;
        }

        #sDetails
        {
            margin-left:15%;
        }

        #filterPane
        {
            top:250px;
            left:805px;
            width:20cm;
            height: fit-content;
            margin-left:170px;
            margin-top: 35px;
        }

        #filterDetails
        {
            position:relative;
            margin-left: 0px;
           
        }

        #filterTable
        {
            width: 4cm;
        }

        #closePopup
        {
            background-color: burlywood;
            border-style:none;
            width: 2cm;
            height: 1cm;
            margin-left: 500px;
            margin-top:15px;
            color: white;
            border-radius: 15px;
                
        }

        #closePopup:hover
        {
            background-color: rgb(180, 145, 101);
        }

        .show 
        {
            display: block;   
        }
        
        h
        {
          
            font-size: 16pt;
            margin-left: 4%;
        }

        img
        {
            height: 150px;
            width: 150px;
            border-radius: 15%;
        }

        img:hover
        {
            height: 130px;
            width: 130px;
            border-radius: 15%;

            border-width: 5pt;
            border-color: white;
            border-style: solid;
          
            transition: all 200ms ease-in-out;
        }
        
        #shortlisted
        {
            height: 100px;
            width: 100px;
            position: fixed;
            margin-left: 92%;
            margin-top: 25%;
            opacity: 0.2;

            
        }
        #shortlisted:hover
        {
            height: 105px;
            width: 105px;
            position: fixed;

            opacity: 1;  
            transition:all 150ms ease-in; 
        }

        #serviceList
        {
            margin-left:7%;
        }

        td
        {
            width: 9cm;
        }

        .NotifBrief
        {
            text-align: left;
        }

        .subheading
        {
            margin-left: 7%;
        }
            
    </style>

    <style>



table {
    width: 80%;
    margin-left: 7%;
    margin-bottom: 20px;
    border-collapse: collapse;
    font-family: Arial, Helvetica, sans-serif;
    border: none; 
    border-radius: 10px; 
    overflow: hidden; 
}

th, td {
    padding: 8px;
    text-align: center;
}

th {
    background-color: rgb(216, 206, 206);
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}

.header-row {
    display: flex;
    align-items: center;
    margin-bottom: 10px; 
}

.title {
    flex: 1; 
    margin-right: 10px; 
}

.search-bar {
    width: 200px; 
    margin-right: 10px; 
    border-radius: 20px; 
    padding: 5px; 
    background-color: #f2f2f2;
}

td {
    cursor: pointer; 
}

.filter-dropdown {
    width: 20px; 
    margin-right: 10px; 
    border-radius: 20px; 
    padding: 5px;
    background-color: #f2f2f2;
}
    

    </style>

    <script>

        class formatter
        {
            showStatus()
            {
                var space=document.createElement('br');
                //space.textContent="Appointments ";//must point an array elemnt
                document.body.append(space); 

                var subheading=document.createElement('h3');
                subheading.textContent="Appointments' status ";//must point an array elemnt
                document.body.append(subheading); 

                var table=document.createElement('table');
                    document.body.appendChild(table);
                    table.setAttribute('class','table');
                    table.setAttribute('id','table');

                    row=document.createElement('tr');
                    table.append(row);

                    cell=document.createElement('td');
                    cell.textContent="Appointment Deposit";//must point an array elemnt
                    row.append(cell); 

                    
                    cell=document.createElement('td');
                    cell.textContent=" ";//must point an array elemnt
                    row.append(cell); 
                    

                    cell=document.createElement('td');
                    cell.textContent="Appointment Status ";//must point an array elemnt
                    row.append(cell);

                    var row;
                    var rows=0;
                    var totalrows= localStorage.length;
                    var cells=0;
                    var cell;
                    var sets=0;
                    var numbering=0;
                    
                        
                        //these are determined by number of keys
                        while(rows<1)
                        {
                            row=document.createElement('tr');
                            table.append(row);
                            numbering++;

                            //cells here have to get data from the arrays
                            cell=document.createElement('td');
                            cell.textContent="R2 000.00 ";//must point an array elemnt
                            row.append(cell); 
                            numbering++;
                            
                            

                            cell=document.createElement('td');
                            cell.textContent="";
                            row.append(cell);
                            numbering++;

                            cell=document.createElement('td');
                            cell.textContent="Awaiting Confirmation ";
                            row.append(cell);
                            
                            rows++;
                        }

            }

            showAppointments()
            {


                //var space=document.createElement('br');
                //space.textContent="Appointments ";//must point an array elemnt
                //document.body.append(space); 
                //var space=document.createElement('br');
                //space.textContent="Appointments ";//must point an array elemnt
                //document.body.append(space); 
                
                //var space=document.createElement('br');
                //space.textContent="Appointments ";//must point an array elemnt
                //document.body.append(space); 

                var subheading=document.createElement('h3');
                subheading.textContent="Notifications ";//must point an array elemnt
                subheading.setAttribute('class','subheading');
                document.body.append(subheading); 

              


                var table2=document.createElement('table');
                    document.body.appendChild(table2);

                    table2.setAttribute('class','table2');
                    table2.setAttribute('id','table2');
                    row2=document.createElement('tr');
                    table2.append(row2);
                    
                    subheading=document.createElement('tr');
                    table2.append(subheading);
                    cell2=document.createElement('td');
                    cell2.textContent=" ";//must point an array elemnt
                    row2.append(cell2); 
                    
                   
                    
                    
                    cell2=document.createElement('td');
                    cell2.textContent=" ";//must point an array elemnt
                    row2.append(cell2);
                    
                   
                    

                    cell2=document.createElement('td');
                    cell2.textContent="Delete All ";//must point an array elemnt
                    cell2.setAttribute('onclick','newformatter.removeAllRows()');
                    row2.append(cell2);
                    
                    
                    var row2;
                    var rows2=0;
                    var totalrows= localStorage.length;
                    var cells=0;
                    var cell2;
                    var sets=0;
                    var numbering2=0;
                    var rowsCreated=Math.floor(Math.random()*15);
                    var rowNumber=0;

                        //these are determined by number of keys
                        while(rows2<rowsCreated)
                        {
                            var idName='row'+rowNumber;
                            row2=document.createElement('tr');
                            row2.setAttribute('id',idName);
                            table2.append(row2);
                            numbering2++;

                            //cells here have to get data from the arrays
                            cell2=document.createElement('td');
                            cell2.textContent=Math.floor(Math.random()*23)+":"+Math.floor(Math.random()*59);//must point an array elemnt
                            row2.append(cell2); 
                            numbering2++;

                            

                            //give handle             
                            cell2=document.createElement('td');
                            cell2.textContent="This will be a brief description of the notification...";
                            cell2.setAttribute('id','appointmentDetails');
                            cell2.setAttribute('class','NotifBrief');
                            cell2.setAttribute('onclick','newformatter.showPop()');
                            row2.append(cell2);
                            numbering2++;

                            

                            cell2=document.createElement('td');
                            cell2.textContent="Delete";
                            cell2.setAttribute('onclick', 'newformatter.removeRows('+idName+')');
                            row2.append(cell2);
                            
                            rows2++;
                            rowNumber++;
                        }

                    //sets++;
            }

            removeAllRows()
            {
               
                    table2.remove();
               
               return 0;
            }

            removeRows(rowToDelete)
            {
                //var row=document.getElementById(''+rowToDelete+'');
                rowToDelete.remove();
                
            }


            showPop(info)
            {
                //this popup must alter elements and content in the popup
                popupBack.classList.add("show");
                var textdata=document.getElementById('textdata');
                
                if(info==1)
                {
                    textdata.textContent="First";
                }
                
                if(info==2)
                {
                    textdata.textContent="Second";
                }

                if(info==1000)
                {
                    textdata.textContent="This is the shortlist";
                }
                
            }

            removePop()
            {
                popupBack.classList.remove("show");
            }

            removeByBackground()
            {
                if (event.target == popupBack) 
                {
                    popupBack.classList.remove("show");
                }
            }

        }
        
        var newformatter= new formatter(); 
        //newformatter.showStatus();
        newformatter.showAppointments();
        //newformatter.runPopup();
       // newformatter.addEventListener("click", function () { newformatter.removePop(); });

    
    </script>
    <?php include '../partial/footer.php';?>    

    
</body>
</html>