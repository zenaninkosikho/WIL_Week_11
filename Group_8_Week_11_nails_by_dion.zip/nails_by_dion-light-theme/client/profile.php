<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
    <link rel="stylesheet" href="/../styles/client_styles.css">
</head>
<body>
    <?php include $page = 'profile'; include '../partial/header.php';?>
    <section>
        <header>
            <h2>Profile Information</h2>
            <p>Update your account's profile information and email address.</p>
        </header>

        <form class="profile-form">
            <div>
                <label for="name">Name</label>
                <input type="text" id="name" name="name" required>
                <!--<p id="name_error" style="color: red;">you name is required</p>-->      
            </div>

            <div>
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
                <!--<p id="email_error" style="color: red;">The email you have entered is not valid</p>-->
            </div>

            <div>
                <label for="cell">Cell No.</label>
                <input type="text" id="cell" name="cell">
                <!--<p id="email_error" style="color: red;">The phone number you have entered is not valid</p>-->
            </div>

            <button type="submit" class="profile-button">Update</button>
            <button type="reset" class="profile-button">Reset</button>
        </form>
    </section>

    <section>
        <header>
            <h2>Update Password</h2>
            <p>Ensure your account is using a long, random password to stay secure.</p>
        </header>

        <form class="profile-form">
            <div>
                <label for="update_password_current">Current Password</label>
                <input type="password" id="update_password_current" name="current_password" required>
                <!--<p id="current_password_error" style="color: red;">the password you have entered was invalid</p>-->
            </div>

            <div>
                <label for="update_password_new">New Password</label>
                <input type="password" id="update_password_new" name="new_password" required>
                <!--<p id="new_password_error_length" style="color: red;">the password need to be at least 8 characters long</p>
                <<p id="new_password_error_special" style="color: red;">the password need to contain a spacial character</p>
                <<p id="new_password_error_caps" style="color: red;">the password need contain an upper case letter</p>-->
                
            </div>

            <div>
                <label for="update_password_confirm">Confirm Password</label>
                <input type="password" id="update_password_confirm" name="confirm_password" required>
                <!--<p id="confirm_password_error" style="color: red;">the password does not match with the new password</p>-->
            </div>

            <button type="submit" class="profile-button">Update</button>
            <button type="reset" class="profile-button">Reset</button>
            </div>
        </form>
    </section>

    <section class="space-y-6">
        <header>
            <h2>Unsubscribe</h2>
            <p>Once your have unsubscribed, you will no longer receive important updates, promotions, and exclusive offers.</p>
        </header>

        <button class="unsubscribe profile-button">Unsubscribe</button>
    </section>
</body>
</html>