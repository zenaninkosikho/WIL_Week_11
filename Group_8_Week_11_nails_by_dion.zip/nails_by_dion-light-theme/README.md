# nails-by-dion

## Resources
### Layout
* **Grid-Layout** - https://youtu.be/EiNiSFIPIQE?si=bA5EkL-3NmJUDfxu
* **Grid-Layout Tool** - https://cssgrid-generator.netlify.app/
* **Sub-Grid** - https://youtu.be/Yl8hg2FG20Q?si=KBlpbydy9jFT9iCx
---
### Design
* **Fonts** - https://fonts.google.com/?colors=000000-f3e6d9-d5b698-b8936f-4c3a00&fonts=Poppins-Poppins
* **Colors** - https://colorhunt.co/
* **Icons** - https://fontawesome.com/icons
* **Test fonts and colors** - https://www.realtimecolors.com/?colors=000000-f3e6d8-d6b89a-b8946f-4d3b00&fonts=Poppins-Inter
---
## Admin
* **Charts** - https://youtu.be/sE08f4iuOhA?si=d-FIgEnIU_pdde6m
* **Template** - https://themewagon.com/theme-framework/chart-js/
--- 
# Data Storage
* **JSON** - https://youtu.be/iiADhChRriM?si=InT03vf48Jq0W749

# Components
* **codepen** - https://codepen.io/
* **uiverse** - https://uiverse.io/