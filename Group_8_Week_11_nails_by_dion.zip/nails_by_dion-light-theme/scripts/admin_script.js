// SIDEBAR TOGGLE

let sidebarOpen = false;
const sidebar = document.getElementById('sidebar');

function openSidebar() {
  if (!sidebarOpen) {
    sidebar.classList.add('sidebar-responsive');
    sidebarOpen = true;
  }
}

function closeSidebar() {
  if (sidebarOpen) {
    sidebar.classList.remove('sidebar-responsive');
    sidebarOpen = false;
  }
}

// NOTIFICATIONS

// Wait for the DOM content to load
document.addEventListener('DOMContentLoaded', function() {
  // Get all message boxes
  var messageBoxes = document.querySelectorAll('.message-box');

  // Get the element displaying the number of unread notifications
  var unreadCountElement = document.getElementById('notification-count');

  // Initialize unread count
  var unreadCount = messageBoxes.length;

  // Update unread count display
  unreadCountElement.textContent = unreadCount;

  // Loop through each message box
  messageBoxes.forEach(function(messageBox) {
      // Add click event listener to each message box
      messageBox.addEventListener('click', function() {
          // Toggle the class for message-read
          this.classList.toggle('message-read');
          
          // Update unread count based on the class change
          if (this.classList.contains('message-read')) {
              unreadCount--;
          } else {
              unreadCount++;
          }

          // Update the display of unread count
          unreadCountElement.textContent = unreadCount;
      });
  });
});

document.querySelectorAll('.message-box').forEach(box => {
  box.addEventListener('click', () => {
    box.querySelector('.full-message').classList.toggle('show');
  });
});

// CHARTS
let page = window.location.pathname;
if (page == '/admin/dashboard.php'){
  displayMonthlySales('dashboard-sales-monthly');
  displayWeeklySales('dashboard-sales-weekly');
  displayServiceRevenue('dashboard-service-revenue');
  displayCustomerNumber('dashboard-customer-number');
}else 
if(page == '/admin/sale.php'){
  displayMonthlySales('sales-monthly');
  displayWeeklySales('sales-weekly');
  displayServiceRevenue('service-revenue');
}else 
if(page == '/admin/customer.php'){
  displayCustomerNumber('customer-number');
}
function displayMonthlySales(id) {
  let monthlySales = document.getElementById(id).getContext('2d');

  let dashboardSalesMonthly = new Chart(monthlySales, {
    type: 'line',
    data: {
      labels: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
      datasets: [{
        label: 'Monthly Sales',
        data: [50000, 45000, 30000, 35000, 40000, 55000, 50000, 52000, 60000, 55000, 60000, 75000],
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(153, 102, 255, 0.2)',
          'rgba(255, 159, 64, 0.2)',
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(153, 102, 255, 0.2)',
          'rgba(255, 159, 64, 0.2)'
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
          'rgba(255, 159, 64, 1)',
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
          'rgba(255, 159, 64, 1)'
        ],
        borderWidth: 1,
        hoverOffset: 4,
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
}

function displayWeeklySales(id) { 
  let weeklySales = document.getElementById(id).getContext('2d');

  let dashboardSalesWeekly = new Chart(weeklySales, {
    type: 'bar',
    data: {
      labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
      datasets: [{
        label: 'Daily Sales',
        data: [5000, 4500, 3000, 3500, 4000, 5500, 5000],
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(153, 102, 255, 0.2)',
          'rgba(255, 159, 64, 0.2)',
          'rgba(255, 99, 132, 0.2)'
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
          'rgba(255, 159, 64, 1)',
          'rgba(255, 99, 132, 1)'
        ],
        borderWidth: 1,
        hoverOffset: 4,
      }]
    },
    options: {
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  })
};

function displayServiceRevenue(id) {
  let serviceRevenue = document.getElementById(id).getContext('2d');

  let dashboardServiceRevenue = new Chart(serviceRevenue, {
    type: 'bar',
    data: {
      labels: ['Service 1', 'Service 2', 'Service 3', 'Service 4', 'Service 5', 'Service 6', 'Service 7', 'Service 8', 'Service 9', 'Service 10'],
      datasets: [{
        label: 'Top Service this Month',
        data: [5000, 7500, 6500, 4000, 9000, 5000, 4500, 8200, 4000, 5500],
        backgroundColor: [
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(153, 102, 255, 0.2)',
          'rgba(255, 159, 64, 0.2)',
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(75, 192, 192, 0.2)'
        ],
        borderColor: [
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)',
          'rgba(153, 102, 255, 1)',
          'rgba(255, 159, 64, 1)',
          'rgba(255, 99, 132, 1)',
          'rgba(54, 162, 235, 1)',
          'rgba(255, 206, 86, 1)',
          'rgba(75, 192, 192, 1)'
        ],
        borderWidth: 1,
        hoverOffset: 4,
      }]
    },
    options: {
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true
        }
      },
      indexAxis: 'y'
    }
  })
};

function displayCustomerNumber(id) {
  let CustomerNumber = document.getElementById(id).getContext('2d');

  let NumOfCustomers = new Chart(CustomerNumber, {
    type: 'line',
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
      datasets: [
        {
          label: 'Subscribers',
          data: [100, 150, 140, 250, 350, 320, 380, 450, 400, 420, 490, 550],
          borderColor: 'blue',
          fill: false
        }, 
        {
          label: 'Loyalty Members',
          data: [50, 70, 100, 90, 110, 150, 140, 165, 180, 203, 227, 225],
          borderColor: 'green',
          fill: false
        }]
    },
    options: {
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
}
// TEAM

document.addEventListener("DOMContentLoaded", function () {
  const form = document.getElementById("add-member-form");
  form.addEventListener("submit", function (e) {
      e.preventDefault();
      console.log("Form submitted"); // Add this line to check if the event listener is triggered
      // Retrieve input values
      const name = document.getElementById("member-name").value;
      const email = document.getElementById("member-email").value;
      const role = document.getElementById("member-role").value;
      console.log(name, email, role); // Add this line to check if the input values are retrieved correctly
      // Create a new team card
      const newCard = document.createElement("div");
      newCard.classList.add("card-container");
      newCard.innerHTML = `
          <div class="team-card">
              <img id="team-pic" src="../_images/profile-pic blank.jpeg" alt="team-profile photo">
              <p id="team-name">${name}</p>
              <p id="team-email">${email}</p>
              <div class="card-bottom">
                  <p class="team-role">${role}</p>
                  <button id="team-view">View</button>
              </div>
          </div>
      `;
      console.log(newCard); // Add this line to check if the new card is created properly
      // Append the new card to the deck
      const deck = document.querySelector(".deck");
      console.log(deck); // Add this line to check if the deck container is selected correctly
      deck.appendChild(newCard);
      // Clear the form inputs
      form.reset();
  });
});


