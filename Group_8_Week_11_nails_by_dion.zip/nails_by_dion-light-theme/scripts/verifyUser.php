<?php
session_start();
function loginUser($email, $password) {
    // get user.json directory
    $filePath = __DIR__ . '/../data/users.json';
    // get data from users.json
    $usersData = file_get_contents($filePath);
    $users = json_decode($usersData, true);

    // Check if the user exists
    $validUser = '';
    foreach ($users['user'] as $user) {
        if ($user['email'] === $email && password_verify($password, $user['password'])) {
            $validUser = $user;
            break;
        }
    }

    return $validUser;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get form data
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Call the loginUser function
    $user = loginUser($email, $password);
    if ($user['type'] == 'Admin') {
        $_SESSION["user"] = $user;
        header('Location: /../admin/dashboard.php');
    } else 
    if ($user['type'] == 'Client') {
        $_SESSION["user"] = $user;
        header('Location: /../client/index.php');
    } else {
        echo "<script>alert('Invalid email or password. Please try again.');</script>";
    }
}
?>