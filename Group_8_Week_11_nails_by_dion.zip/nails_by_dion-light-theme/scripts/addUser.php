<?php
// get user.json directory
$filePath = __DIR__ . '/../data/users.json';
// Get user data
$usersData = file_get_contents($filePath);
$users = json_decode($usersData, true);

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$cell = $_POST['cell'];
$password = $_POST['password'];
$hashedPassword = password_hash($password, PASSWORD_DEFAULT);

//--------------------------------

$newUser = array('name' => $name, 'email' => $email, 'cell' => $cell, 'password' => $hashedPassword, 'type' => 'Client');

// Append the new user to the existing users array
$users['user'][] = $newUser;

// Save the updated user data back to users.json
file_put_contents($filePath, json_encode($users, JSON_PRETTY_PRINT));

echo "<script>alert('User registered successfully!')</script>";
header('Location: /../auth/login.php');

