<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // get user.json directory
    $filePath = __DIR__ . '/../data/users.json';
    // get data from users.json
    $usersData = file_get_contents($filePath);
    $users = json_decode($usersData, true);

    // Check if the user exists
    $validUser = '';
    foreach ($users['user'] as $key => $u) {
        if ($u == $_SESSION['user']) {
            $users['user'][$key]['name'] = $name;
            $users['user'][$key]['email'] = $email;
            $users['user'][$key]['cell'] = $cell;
            break;
        }
    }

    $newUserData = json_encode($users,JSON_PRETTY_PRINT);
    file_put_contents($filePath, $newUserData);
    header('Location: /../admin/admin_profile.php');
}